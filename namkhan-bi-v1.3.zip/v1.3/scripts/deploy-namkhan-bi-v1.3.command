#!/usr/bin/env bash
# deploy-namkhan-bi-v1.3.command
set -euo pipefail

REPO_DIR="${REPO_DIR:-$HOME/Desktop/namkhan-bi}"

cd "$REPO_DIR"

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: uncommitted changes. Run 'git stash' first."
  exit 1
fi

git checkout main
git pull origin main --ff-only
git branch "v1.3-backup-$(date +%Y%m%d-%H%M%S)"

# All file writes happen here — ask Cowork to paste each block from the deployment doc
# into the indicated path, then run:

if ! grep -q "v1.3 · UserMenu" styles/globals.css; then
  echo "ERROR: styles/globals.css does not have the v1.3 CSS block appended."
  echo "Paste the v1.3 CSS into styles/globals.css before running."
  exit 1
fi

# Critical file checks
for f in lib/currentUser.ts components/nav/UserMenu.tsx app/api/logout/route.ts \
         app/settings/property/page.tsx app/settings/users/page.tsx \
         app/settings/budget/page.tsx app/settings/integrations/page.tsx \
         app/settings/notifications/page.tsx app/settings/reports/page.tsx \
         app/settings/dq/page.tsx; do
  if [ ! -f "$f" ]; then
    echo "ERROR: missing $f"
    exit 1
  fi
done

# Banner.tsx must be the new async server component with UserMenu
if ! grep -q "UserMenu" components/nav/Banner.tsx; then
  echo "ERROR: components/nav/Banner.tsx not updated to include UserMenu"
  exit 1
fi

# subnavConfig.ts must have settings entry
if ! grep -q "settings:" components/nav/subnavConfig.ts; then
  echo "ERROR: components/nav/subnavConfig.ts not updated with settings subnav"
  exit 1
fi

# Build to catch TS errors before pushing
npm run build || {
  echo "ERROR: build failed. Fix locally before pushing."
  exit 1
}

git add -A
git commit -m "v1.3: top-right user menu + role-gated Settings sub-pages

- New: UserMenu component (avatar + name + role + dropdown)
- New: 7 settings sub-pages — Property, Users, Budget, Integrations, Notifications, Reports, DQ engine
- New: lib/currentUser (mock auth, defaults to seeded owner)
- New: /api/logout route (clears cookies)
- Modified: Banner now async, fetches current user, slots UserMenu in top-right
- Modified: subnavConfig adds settings sub-tabs
- Modified: settings/page.tsx adds SubNav (existing 4 cards preserved)
- Appended: globals.css v1.3 block (UserMenu styles)

Backend: app_users, app_settings, action_decisions tables already live in Supabase."

git push origin main
echo "DONE. Vercel will auto-deploy."
