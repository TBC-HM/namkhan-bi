# v1.3 — UserMenu + role-gated Settings sub-pages

## What's in this zip

```
v1.3/
├── README.md                          ← this file
├── lib/
│   └── currentUser.ts                 ← NEW — drop in
├── components/nav/
│   ├── Banner.tsx                     ← REPLACE existing file
│   └── UserMenu.tsx                   ← NEW — drop in
├── app/
│   ├── api/logout/route.ts            ← NEW — drop in
│   └── settings/
│       ├── property/page.tsx          ← NEW — drop in
│       ├── users/page.tsx             ← NEW — drop in
│       ├── budget/page.tsx            ← NEW — drop in
│       ├── integrations/page.tsx      ← NEW — drop in
│       ├── notifications/page.tsx     ← NEW — drop in
│       ├── reports/page.tsx           ← NEW — drop in
│       └── dq/page.tsx                ← NEW — drop in
├── styles/
│   └── globals.append.css             ← APPEND contents to existing styles/globals.css
└── scripts/
    └── deploy-namkhan-bi-v1.3.command ← run after files are in place
```

## Deploy steps

### 1. Drop NEW files (no manual edits needed)

Copy these straight into the repo at the same paths:

- `lib/currentUser.ts`
- `components/nav/UserMenu.tsx`
- `app/api/logout/route.ts`
- `app/settings/property/page.tsx`
- `app/settings/users/page.tsx`
- `app/settings/budget/page.tsx`
- `app/settings/integrations/page.tsx`
- `app/settings/notifications/page.tsx`
- `app/settings/reports/page.tsx`
- `app/settings/dq/page.tsx`

### 2. REPLACE `components/nav/Banner.tsx`

Overwrite the existing file with the one in this zip. Props interface unchanged — every existing call site keeps working.

### 3. APPEND CSS

Open `styles/globals.css` in the repo. Paste the entire contents of `styles/globals.append.css` at the bottom. Do NOT modify or remove anything above.

### 4. MANUAL EDIT — `components/nav/subnavConfig.ts`

Add the `settings:` key to the `RAIL_SUBNAV` object. Don't touch existing keys.

```ts
  settings: [
    { href: '/settings',                label: 'Snapshot' },
    { href: '/settings/property',       label: 'Property' },
    { href: '/settings/users',          label: 'Users & roles' },
    { href: '/settings/budget',         label: 'Budget' },
    { href: '/settings/integrations',   label: 'Integrations' },
    { href: '/settings/notifications',  label: 'Notifications' },
    { href: '/settings/reports',        label: 'Reports' },
    { href: '/settings/dq',             label: 'DQ engine' },
  ],
```

If `PILLAR_HEADER` doesn't already have a settings entry, also add:

```ts
  settings: { eyebrow: 'Settings', title: 'Property', emphasis: 'configuration', sub: 'Preferences · users · API keys · profile' },
```

### 5. MANUAL EDIT — `app/settings/page.tsx`

Add 2 imports and 1 line of JSX. Keep everything else exactly as live.

```diff
+ import SubNav from '@/components/nav/SubNav';
+ import { RAIL_SUBNAV } from '@/components/nav/subnavConfig';

  // ... existing imports unchanged ...

  export default function SettingsPage() {
    return (
      <>
        <Banner ... />
+       <SubNav items={RAIL_SUBNAV.settings} />
        <div className="panel">
          {/* existing 4-card content stays exactly as-is */}
        </div>
      </>
    );
  }
```

### 6. Run the deploy script

```bash
chmod +x scripts/deploy-namkhan-bi-v1.3.command
REPO_DIR=/path/to/namkhan-bi ./scripts/deploy-namkhan-bi-v1.3.command
```

The script:
- Verifies all required files exist
- Verifies the v1.3 CSS block was appended
- Verifies Banner.tsx now includes UserMenu
- Verifies subnavConfig.ts has the settings entry
- Runs `npm run build` to catch TS errors
- Commits and pushes to main → Vercel auto-deploys

## Post-deploy verification (~90s after push)

| URL | Expected |
|-----|----------|
| `/overview` | Top-right shows "PB" avatar + "Paul Bauer" + "Owner" pill |
| Click avatar | Dropdown: Settings · Notifications · Switch property (greyed) · Help & docs · Sign out |
| `/settings` | Same 4 cards as before BUT now with sub-nav above showing 8 tabs |
| `/settings/property` | KPI strip + Property identity table from `app_settings` |
| `/settings/users` | 1 row: Paul Bauer · Owner · Active |
| `/settings/budget` | "Drop CSV here" stub |
| `/settings/integrations` | Cloudbeds + Supabase Connected, Email parser + Vertex greyed |
| `/settings/notifications` | 3 rows: Daily digest On, Review alerts On, DQ alerts On |
| `/settings/reports` | 3 schedule rows + custom report stub |
| `/settings/dq` | Active DQ issues table + resolved table |
| `/api/logout` | Clears cookies, redirects to login |

## Backend (already done)

- `app_users` — 1 row (paul@thenamkhan.com / owner / PB)
- `app_settings` — 9 rows (4 property · 3 notifications · 2 reports)
- `action_decisions` — 0 rows (foundation for Phase 4)

No additional Supabase work needed.

## What this doesn't touch

- `/overview`, `/revenue/*`, `/operations/*`, `/guest/*`, `/finance/*`, `/knowledge` — untouched
- Existing `/settings/page.tsx` snapshot content (4 cards) — preserved
- All KPI/Card/PanelHero/SubNav/FilterStrip/LeftRail components — untouched
- Existing CSS — only appended, never modified
