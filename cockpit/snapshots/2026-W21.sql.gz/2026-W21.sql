--
-- PostgreSQL database dump
--

\restrict Hlzy4qNbncaJdVzgYpXDByGPnGMbXqyx8IOoOymGopPBuY67KVCbB56hMFT5Jjt

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cockpit_agent_identity; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_agent_identity AS
 SELECT role,
    display_name,
    avatar,
    tagline,
    color,
    created_at,
    org_id,
    property_id,
    reports_to,
    dept,
    status,
    hierarchy_level,
    updated_at,
    scope,
    agent_id
   FROM cockpit.id_agents;


--
-- Name: cockpit_agent_memory; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_agent_memory WITH (security_invoker='true') AS
 SELECT id,
    agent_handle,
    memory_type,
    content,
    embedding,
    embedded_at,
    embedding_model,
    topics,
    source_ticket_id,
    source_audit_log_id,
    confidence,
    importance,
    last_recalled_at,
    recall_count,
    active,
    superseded_by,
    archived_at,
    archived_reason,
    created_at,
    updated_at,
    org_id,
    property_id
   FROM cockpit.kn_agent_memory;


--
-- Name: cockpit_agent_prompts; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_agent_prompts WITH (security_invoker='true') AS
 SELECT id,
    role,
    prompt,
    version,
    active,
    notes,
    source,
    ticket_id,
    created_at,
    updated_at,
    department,
    status,
    archived_at,
    archived_reason,
    can_be_reactivated
   FROM cockpit.cap_prompts;


--
-- Name: cockpit_agent_skills; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_agent_skills WITH (security_invoker='true') AS
 SELECT id,
    name,
    description,
    input_schema,
    handler,
    active,
    notes,
    created_at,
    updated_at,
    authority_level,
    requires_pbs_approval,
    requires_dry_run,
    error_codes,
    estimated_cost_usd_milli,
    cost_class,
    implementation_type,
    archived_at,
    archived_reason
   FROM cockpit.cap_skills;


--
-- Name: cockpit_change_log; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_change_log WITH (security_invoker='true') AS
 SELECT id,
    changed_at,
    command_tag,
    object_type,
    schema_name,
    object_identity,
    session_user_name,
    current_user_name,
    client_addr,
    application_name,
    statement,
    metadata
   FROM cockpit.aud_change_log;


--
-- Name: cockpit_decisions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_decisions WITH (security_invoker='true') AS
 SELECT id,
    created_at,
    ticket_id,
    arm,
    title,
    decision,
    reasoning,
    alternatives_considered,
    superseded_by,
    adr_url,
    org_id,
    property_id,
    decided_by,
    approved_by_human,
    impact
   FROM cockpit.exec_decisions;


--
-- Name: cockpit_projects; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_projects WITH (security_invoker='true') AS
 SELECT id,
    slug,
    name,
    description,
    dept,
    owner_role,
    created_by,
    status,
    created_at,
    updated_at,
    archived_at,
    goal
   FROM cockpit.exec_projects;


--
-- Name: cockpit_proposals; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_proposals WITH (security_invoker='true') AS
 SELECT id,
    project_id,
    ticket_id,
    agent_role,
    action_type,
    dept,
    signal,
    body,
    action_payload,
    status,
    requires_approval,
    created_at,
    started_at,
    finished_at,
    evidence,
    rejected_reason
   FROM cockpit.exec_proposals;


--
-- Name: cockpit_standing_tasks; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_standing_tasks WITH (security_invoker='true') AS
 SELECT id,
    slug,
    name,
    description,
    ticket_template,
    active,
    last_run_at,
    run_count,
    created_at
   FROM cockpit.exec_standing_tasks;


--
-- Name: cockpit_tickets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.cockpit_tickets WITH (security_invoker='true') AS
 SELECT id,
    created_at,
    updated_at,
    source,
    arm,
    intent,
    status,
    email_subject,
    email_body,
    parsed_summary,
    pr_url,
    preview_url,
    github_issue_url,
    iterations,
    closed_at,
    notes,
    metadata,
    project_id,
    processed_at
   FROM cockpit.exec_tickets;


--
-- PostgreSQL database dump complete
--

\unrestrict Hlzy4qNbncaJdVzgYpXDByGPnGMbXqyx8IOoOymGopPBuY67KVCbB56hMFT5Jjt


-- cockpit_audit_log (last 30 days, slim slice)
